# Async Request Reply Pattern
ASP.NET Core demo demonstrating async request reply pattern

[Asynchronous operations](https://docs.microsoft.com/en-us/azure/architecture/best-practices/api-design#asynchronous-operations)

[Asynchronous Request-Reply pattern](https://docs.microsoft.com/en-us/azure/architecture/patterns/async-request-reply)

