﻿namespace CompetingConsumer.Services
{
    internal interface IOrderQueue
    {
        void CreateOrders();
    }
}