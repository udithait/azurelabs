﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CompetingConsumer.Services
{
    public interface IMessageTransform
    {
        string MessageTransformation();
    }
}