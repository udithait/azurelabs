﻿namespace DataProcessor.Library
{
    public interface ILogger
    {
        void LogMessage(string message, string data);
    }
}