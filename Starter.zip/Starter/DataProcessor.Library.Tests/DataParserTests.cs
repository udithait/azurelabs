using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading.Tasks;

namespace DataProcessor.Library.Tests
{
    [TestClass]
    public class DataParserTests
    {
        [TestMethod]
        public void ParseData_WithMixedData_ReturnsGoodRecords()
        {
            Assert.Inconclusive();
        }

        [TestMethod]
        public void ParseData_WithGoodRecord_ReturnsOneRecord()
        {
            Assert.Inconclusive();
        }

        [TestMethod]
        public void ParseData_WithBadRecord_ReturnsZeroRecords()
        {
            Assert.Inconclusive();
        }

        [TestMethod]
        public void ParseData_WithBadStartDate_ReturnsZeroRecords()
        {
            Assert.Inconclusive();
        }

        [TestMethod]
        public void ParseData_WithBadRating_ReturnsZeroRecords()
        {
            Assert.Inconclusive();
        }
    }
}