﻿namespace DataProcessor.Library.Tests
{
    public class FakeLogger // : ILogger
    {

    }
}
