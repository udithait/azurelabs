# protected-static-resource
Protecting static content in ASP.NET Core
