﻿namespace PriorityQueueSender
{
    public static class Priority
    {
        public static readonly string High = "highpriority";

        public static readonly string Low = "lowpriority";
    }
}